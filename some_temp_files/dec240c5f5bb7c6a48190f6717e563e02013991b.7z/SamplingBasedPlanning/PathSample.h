#include "./Maze/sampling_maze.h"

#ifndef PATH_SAMPLE_H_
#define PATH_SAMPLE_H_

class PathSample {
 public:
    PathSample() {};
    ~PathSample() {};

   //  virtual void init(const Node* start, const Node* goal);
   //  virtual void sampling(std::vector<Point> path,
   //                        std::vector<Point> visited_order);

 protected:
    int x_range_ = 50;
    int y_range_ = 30;

    Node* start_;
    Node* goal_;
};

#endif