#include "RRT.h"

void RRT::init(const Node& start, const Node& goal, float step_len,
               float goal_sample_rate, int iter_max) {
    start_ = start;
    goal_ = goal;
    step_len_ = step_len;
    goal_sample_rate_ = goal_sample_rate;
    iter_max_ = iter_max;
}
void RRT::set_obastacle_info(const std::vector<std::vector<float>>& boundary,
                             const std::vector<std::vector<float>>& circle,
                             const std::vector<std::vector<float>>& rectangle) {
    obs_boundary = boundary;
    obs_circle = circle;
    obs_rectangle = rectangle;
}

void RRT::sampling() {
    vertex.clear();
    vertex.push_back(start_);
    float dist, theta;
    for (int i = 0; i < iter_max_; i++) {
        Node node_rand = generate_random_node(goal_sample_rate_);
        Node node_near = nearest_neighbor(vertex, node_rand);
        Node node_new = new_state(node_near, node_rand);
        if (!is_collision(node_near, node_new)) {
            vertex.push_back(node_new);
            get_distance_and_angle(dist, theta, node_new, goal_);

            if (dist <= step_len_ && !is_collision(node_new, goal_)) {
                new_state(node_new, goal_);
                extract_path(path, node_new);
                break;
            }
        }
    }
    std::cout << "No any path found. " << std::endl;
    return;
}

Node RRT::generate_random_node(float sample_rate) {
    float delta = delta_;
    std::random_device rd;
    std::mt19937 generator(rd());
    std::normal_distribution<float> random_dist(0.0, 1.0);
    std::uniform_real_distribution<float> uniform_dist_x(0.0 + delta,
                                                         x_range_ - delta);
    std::uniform_real_distribution<float> uniform_dist_y(0.0 + delta,
                                                         y_range_ - delta);
    float rn = random_dist(generator);
    float rx, ry;
    if (rn > sample_rate) {
        rx = uniform_dist_x(generator);
        ry = uniform_dist_y(generator);
        return Node(rx, ry);
    }
    return goal_;
}

Node RRT::nearest_neighbor(const std::vector<Node>& vertex, const Node& node) {
    float dist_min = FLT_MAX;
    int index_min;
    for (int i = 0; i < vertex.size(); i++) {
        float dist = std::hypot(vertex[i].x - node.x, vertex[i].y - node.y);
        if (dist < dist_min) {
            dist_min = dist;
            index_min = i;
        }
    }
    return vertex[index_min];
}

Node RRT::new_state(Node& start, Node& end) {
    float dist, theta;
    get_distance_and_angle(dist, theta, start, end);
    dist = std::min(step_len_, dist);
    Node node_new = Node(start.x + dist * std::cos(theta),
                         start.y + dist * std::sin(theta));
    node_new.parent = &start;
    return node_new;
}

void RRT::get_distance_and_angle(float& dist, float& angle, const Node& start,
                                 const Node& end) {
    float dx = end.x - start.x;
    float dy = end.y - start.y;
    dist = std::hypot(dx, dy);
    angle = std::atan2(dy, dx);
}

std::vector<std::vector<Node>> RRT::get_obs_vertex() {
    float delta = delta_;
    std::vector<std::vector<Node>> obs_list;
    for (auto rectangle : obs_rectangle) {
        float ox = rectangle[0];
        float oy = rectangle[1];
        float w = rectangle[2];
        float h = rectangle[3];
        std::vector<Node> vertex_list;
        vertex_list.push_back(Node(ox - delta, oy - delta));
        vertex_list.push_back(Node(ox + w + delta, oy - delta));
        vertex_list.push_back(Node(ox + w + delta, oy + h + delta));
        vertex_list.push_back(Node(ox - delta, oy + h + delta));
        obs_list.push_back(vertex_list);
    }
    return obs_list;
}

bool RRT::is_collision(const Node& start, const Node& end) {
    if (is_inside_obs(start) || is_inside_obs(end))
        return true;

    // get ray
    Node origi = Node(start.x, start.y);
    Node direct = Node(end.x - start.x, end.y - start.y);
    std::vector<std::vector<Node>> obs_vertex = get_obs_vertex();
    for (auto obs : obs_vertex) {
        Node v1 = obs[0];
        Node v2 = obs[1];
        Node v3 = obs[2];
        Node v4 = obs[3];
        if (is_intersect_rectangle(start, end, origi, direct, v1, v2))
            return true;
        if (is_intersect_rectangle(start, end, origi, direct, v2, v3))
            return true;
        if (is_intersect_rectangle(start, end, origi, direct, v3, v4))
            return true;
        if (is_intersect_rectangle(start, end, origi, direct, v4, v1))
            return true;
    }

    for (auto circle : obs_circle) {
        float x = circle[0];
        float y = circle[1];
        float r = circle[2];
        Node center(x, y);
        if (is_intersect_circle(origi, direct, center, r))
            return true;
    }

    return false;
}

bool RRT::is_inside_obs(const Node& node) {
    float delta = delta_;

    for (auto circle : obs_circle) {
        float x = circle[0];
        float y = circle[1];
        float r = circle[2];
        if (std::hypot(node.x - x, node.y - y) <= r + delta)
            return true;
    }

    for (auto rectangle : obs_rectangle) {
        float x = rectangle[0];
        float y = rectangle[1];
        float w = rectangle[2];
        float h = rectangle[3];
        float dx = node.x - (x - delta);
        float dy = node.y - (y - delta);
        if (dx >= 0 && dx <= w + 2 * delta && dy >= 0 && dy <= h + 2 * delta)
            return true;
    }

    for (auto boundary : obs_boundary) {
        float x = boundary[0];
        float y = boundary[1];
        float w = boundary[2];
        float h = boundary[3];
        float dx = node.x - (x - delta);
        float dy = node.y - (y - delta);
        if (dx >= 0 && dx <= w + 2 * delta && dy >= 0 && dy <= h + 2 * delta)
            return true;
    }
    return false;
}

bool RRT::is_intersect_rectangle(const Node& start, const Node& end,
                                 const Node& o, const Node& d, const Node& a,
                                 const Node& b) {
    Node v1 = o - a;
    Node v2 = b - a;
    Node v3 = Node(-d.y, d.x);
    float div = v2.dot(v3);
    if (div == 0) {
        return false;
    }

    float t1 = std::abs(v2.cross(v1)) / div;
    float t2 = v1.dot(v3) / div;

    if (t1 >= 0 && t2 >= 0 and t2 <= 1) {
        Node shot(o.x + t1 * d.x, o.y + t1 * d.y);
        float dist_obs = calc_dist(start, shot);
        float dist_seg = calc_dist(start, end);
        if (dist_obs <= dist_seg)
            return true;
    }
    return false;
}

bool RRT::is_intersect_circle(const Node& o, const Node& d, const Node& a,
                              float r) {
    float d2 = d.dot(d);
    float delta = delta_;
    if (d2 == 0.f)
        return false;
    float t = (a - o).dot(d) / d2;
    if (t >= 0.f && t <= 1.f) {
        Node shot(o.x + t * d.x, o.y + t * d.y);
        if (calc_dist(shot, a) <= r + delta)
            return true;
    }
    return false;
}

float RRT::calc_dist(const Node& start, const Node& end) {
    return std::hypot(end.x - start.x, end.y - start.y);
}

void RRT::extract_path(std::vector<Node>& path, Node& node) {
    path.clear();
    path.push_back(goal_);
    Node node_now = node;
    while (node_now.parent) {
        node_now = node_now.parent;
        path.push_back(node_now);
    }
}

int main() {
    printf("RRT ... \n");
    Node start = Node(2.f, 2.f);
    Node goal = Node(49.f, 24.f);

    Maze maze = Maze();
    maze.init(start, goal);

    std::vector<std::vector<float>> obs_boundary;
    std::vector<std::vector<float>> obs_circle;
    std::vector<std::vector<float>> obs_rectangle;
    maze.get_obastacle_info(obs_boundary, obs_circle, obs_rectangle);

    RRT sampler = RRT();
    sampler.init(start, goal, 0.5f, 0.05f, 10000);
    sampler.set_obastacle_info(obs_boundary, obs_circle, obs_rectangle);
    sampler.sampling();

    maze.animation(sampler.path, sampler.vertex);
}