#include <random>

#include "PathSample.h"

class RRT {
 public:
    RRT() {};
    ~RRT() {};
    void init(const Node& start, const Node& goal, float step_len,
              float goal_sample_rate, int iter_max);
    void set_obastacle_info(const std::vector<std::vector<float>>& boundary,
                            const std::vector<std::vector<float>>& circle,
                            const std::vector<std::vector<float>>& rectangle);
    void sampling();

    std::vector<Node> vertex;
    std::vector<Node> path;

 private:
    Node generate_random_node(float sample_rate);
    Node nearest_neighbor(const std::vector<Node>& vertex, const Node& node);
    Node new_state(Node& start, Node& end);
    void get_distance_and_angle(float& dist, float& angle, const Node& start,
                                const Node& end);

    void extract_path(std::vector<Node>& path, Node& node);
    bool is_collision(const Node& start, const Node& end);
    bool is_inside_obs(const Node& node);
    bool is_intersect_rectangle(const Node& start, const Node& end,
                                const Node& o, const Node& d, const Node& a,
                                const Node& b);
    bool is_intersect_circle(const Node& o, const Node& d, const Node& a,
                             float r);
    float calc_dist(const Node& start, const Node& end);
    std::vector<std::vector<Node>> get_obs_vertex();

    std::vector<std::vector<float>> obs_boundary;
    std::vector<std::vector<float>> obs_circle;
    std::vector<std::vector<float>> obs_rectangle;

    Node start_;
    Node goal_;
    float step_len_;
    float goal_sample_rate_;
    int iter_max_;

    int x_range_ = 50;
    int y_range_ = 30;
    float delta_ = 0.5f;
};