#include "sampling_maze.h"

#include <cstdio>

Node Node::operator=(Node *node) {
    if (this != node) {
        x = node->x;
        y = node->y;
        parent = node->parent;
    }
    return *this;
}

Node &Node::operator=(const Node &node) {
    // Preventing self-assignment causing node parent pointing to itself
    if (this == &node) {
        return *this;
    }

    x = node.x;
    y = node.y;

    if (node.parent != nullptr) {
        parent = new Node(*node.parent);  // deep-copy parent
    } else {
        parent = nullptr;
    }

    return *this;
}

Maze::Maze() {
    int maze_size = x_range_ * y_range_;
    // g = new float[maze_size];
    // for (int y = 0; y < y_range_; y++) {
    //     for (int x = 0; x < x_range_; x++) {
    //         g[y * x_range_ + x] = MAX_COST;
    //     }
    // }
}

Maze::~Maze() {
    // SAFE_DELETE(g);
}

void Maze::init(const Node &start, const Node &goal) {
    start_ = start;
    goal_ = goal;

    img_width_ = x_range_ * grid_size_;
    img_height_ = y_range_ * grid_size_;
    maze_.create(img_height_, img_width_, CV_8UC3);
    maze_.setTo(cv::Scalar(255, 255, 255));

    init_maze();
    // init_g();

    draw_scatter(start.x, start.y, RECTANGLE, cv::Scalar(255, 0, 0));
    draw_scatter(goal.x, goal.y, RECTANGLE, cv::Scalar(0, 255, 0));
}

void Maze::set_png_save_path(std::string path) { png_save_path_ = path; }

void Maze::get_obastacle_info(std::vector<std::vector<float>> &boundary,
                              std::vector<std::vector<float>> &circle,
                              std::vector<std::vector<float>> &rectangle) {
    boundary = obs_boundary;
    circle = obs_circle;
    rectangle = obs_rectangle;
}

void Maze::animation(std::vector<Node> path, std::vector<Node> node_list) {
    for (Node node : node_list) {
        if (node.parent) {
            cv::Point2f p1 = index_of_image(node.x, node.y);
            cv::Point2f p2 = index_of_image(node.parent->x, node.parent->y);
            cv::line(maze_, p1, p2, cv::Scalar(0, 255, 0), 1);
        }
        cv::imshow("maze", maze_);
        // save_current_maze();
        cv::waitKey(1);
    }
    draw_path(path);
    cv::imshow("maze", maze_);
    // save_current_maze();
    cv::waitKey(0);
}
void Maze::draw_path(std::vector<Node> path) {
    if (path.size() == 0)
        return;
    for (int i = 0; i < path.size() - 1; i++) {
        Node node_1 = path[i];
        Node node_2 = path[i + 1];
        cv::Point2f center_1 = index_of_image(node_1.x, node_1.y);
        cv::Point2f center_2 = index_of_image(node_2.x, node_2.y);
        cv::line(maze_, center_1, center_2, cv::Scalar(0, 0, 255), 2);

        // cv::imshow("maze", maze_);
        // cv::waitKey(100);
    }
}

void Maze::init_maze() {
    obs_boundary = {
        {0, 0, 1, 30},
        {0, 30, 50, 1},
        {1, 0, 50, 1},
        {50, 1, 1, 30},
    };
    obs_rectangle = {
        {14, 12, 8, 2},
        {18, 22, 8, 3},
        {26, 7, 2, 12},
        {32, 14, 10, 2},
    };
    obs_circle = {
        {7, 12, 3}, {46, 20, 2}, {15, 5, 2}, {37, 7, 3}, {37, 23, 3},
    };

    for (int i = 0; i < obs_boundary.size(); i++) {
        add_obstacle(obs_boundary[i], BOUNDARY, cv::Scalar(0, 0, 0));
    }
    for (int i = 0; i < obs_rectangle.size(); i++) {
        add_obstacle(obs_rectangle[i], RECTANGLE, cv::Scalar(128, 128, 128));
    }
    for (int i = 0; i < obs_circle.size(); i++) {
        add_obstacle(obs_circle[i], CIRCLE, cv::Scalar(128, 128, 128));
    }
}

void Maze::draw_scatter(int x, int y, int type, cv::Scalar color) {
    cv::Point2d center = index_to_center(x, y);
    int half_grid_size = grid_size_ / 2;

    if (type == RECTANGLE) {
        cv::Point2d point_tl =
            cv::Point2d(center.x - half_grid_size, center.y - half_grid_size);
        cv::Point2d point_br =
            cv::Point2d(center.x + half_grid_size, center.y + half_grid_size);
        cv::rectangle(maze_, point_tl, point_br, color, cv::FILLED);
    } else if (type == CIRCLE) {
        cv::circle(maze_, center, half_grid_size, color, cv::FILLED);
    } else {
    }
}

cv::Point2d Maze::index_to_center(int x, int y) {
    int half_grid_size = grid_size_ / 2;
    cv::Point2d point;
    point.x = x * grid_size_ + half_grid_size;
    point.y = y * grid_size_ + half_grid_size;
    return point;
}

cv::Point2f Maze::index_of_image(float x, float y) {
    float half_grid_size = grid_size_ / 2.f;
    cv::Point2f point;
    point.x = x * grid_size_ + half_grid_size;
    point.y = y * grid_size_ + half_grid_size;
    return point;
}

void Maze::add_obstacle(std::vector<float> obs_info, int type,
                        cv::Scalar color) {
    if (type == RECTANGLE || type == BOUNDARY) {
        cv::Rect2f range(obs_info[0], obs_info[1], obs_info[2], obs_info[3]);
        add_rectangle_obstacle(range, color, type);
    } else if (type == CIRCLE) {
        cv::Point2f center(obs_info[0], obs_info[1]);
        float r = obs_info[2];
        add_circle_obstacle(center, r, color);
    } else {
    }
}

void Maze::add_rectangle_obstacle(cv::Rect2f obs, cv::Scalar color, int type) {
    float half_grid_size = grid_size_ / 2.f;
    cv::Rect2f obs_range;
    obs_range.x = obs.x * grid_size_;
    obs_range.y = obs.y * grid_size_;
    if (type == RECTANGLE) {
        obs_range.x += half_grid_size;
        obs_range.y += half_grid_size;
    }
    obs_range.width = obs.width * grid_size_;
    obs_range.height = obs.height * grid_size_;

    cv::rectangle(maze_, obs_range, color, cv::FILLED);
}

void Maze::add_circle_obstacle(cv::Point2f center, float radius,
                               cv::Scalar color) {
    float half_grid_size = grid_size_ / 2.f;
    center.x = center.x * grid_size_ + half_grid_size;
    center.y = center.y * grid_size_ + half_grid_size;
    radius = radius * grid_size_;

    cv::circle(maze_, center, radius, color, cv::FILLED);
}

void Maze::save_current_maze() {
    cv::imwrite(png_save_path_ + std::to_string(frame_count_) + ".png", maze_);
    frame_count_++;
}