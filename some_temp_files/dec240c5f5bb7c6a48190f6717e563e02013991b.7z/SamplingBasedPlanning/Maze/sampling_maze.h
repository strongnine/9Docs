#include <opencv2/opencv.hpp>
#include <vector>

#ifndef SAMPLING_MAZE_H_
#define SAMPLING_MAZE_H_

#define SAFE_DELETE(P)    \
    {                     \
        if (P)            \
            delete[] (P); \
        (P) = nullptr;    \
    }

#define OBS_COST (-(FLT_MAX / 2))
#define MAX_COST (FLT_MAX / 2)

enum ScatterTypes {
    CIRCLE = 1,
    RECTANGLE = 2,
    BOUNDARY = 3,
};

struct Node {
    Node() : x(0.f), y(0.f), parent(nullptr) {};
    Node(Node& node) : x(node.x), y(node.y), parent(node.parent) {};
    Node(const Node& node) {
        x = node.x;
        y = node.y;
        if (node.parent != nullptr) {
            parent = new Node(*node.parent);  // deep-copy parent
        } else {
            parent = nullptr;
        }
    };
    Node(float x, float y) : x(x), y(y), parent(nullptr) {};
    Node(float x, float y, Node* parent) : x(x), y(y), parent(parent) {};
    Node operator=(Node* node);
    Node& operator=(const Node& node);

    bool operator==(const Node& p) const {
        return this->x == p.x && this->y == p.y;
    }

    bool operator!=(const Node& p) const {
        return this->x != p.x || this->y != p.y;
    }

    Node operator-(const Node& p) const {
        return Node(this->x - p.x, this->y - p.y);
    }

    Node operator+(const Node& p) const {
        return Node(this->x + p.x, this->y + p.y);
    }

    float dot(const Node& p) const { return this->x * p.x + this->y * p.y; }

    float cross(const Node& p) const { return this->x * p.y - p.x * this->y; }

    float x;
    float y;
    Node* parent;
};

// typedef std::pair<float, float> Point;

class Maze {
 public:
    Maze();
    ~Maze();

    void init(const Node& start, const Node& goal);
    void animation(const std::vector<Node> path,
                   const std::vector<Node> node_list);

    void set_png_save_path(std::string path);

    void get_obastacle_info(std::vector<std::vector<float>>& boundary,
                            std::vector<std::vector<float>>& circle,
                            std::vector<std::vector<float>>& rectangle);

    // float* g;

 private:
    cv::Point2d index_to_center(int x, int y);
    cv::Point2f index_of_image(float x, float y);
    void init_maze();
    // void init_g();

    void draw_scatter(int x, int y, int type, cv::Scalar color);
    void draw_path(std::vector<Node> path);
    void add_obstacle(std::vector<float> obs_info, int type, cv::Scalar color);
    void add_rectangle_obstacle(cv::Rect2f obs, cv::Scalar color,
                                int type);
    void add_circle_obstacle(cv::Point2f center, float radius,
                             cv::Scalar color);

    void save_current_maze();

    cv::Mat maze_;
    float grid_size_ = 11.f;
    int x_range_ = 50;
    int y_range_ = 30;
    std::vector<std::vector<float>> obs_boundary;
    std::vector<std::vector<float>> obs_circle;
    std::vector<std::vector<float>> obs_rectangle;

    int img_width_, img_height_;

    Node start_;
    Node goal_;

    std::string png_save_path_ = "../data/png/";
    int frame_count_ = 0;
};

#endif